export class Food {
  name: string;
  warranty: string;
  quality: string;
  price: number;
}
