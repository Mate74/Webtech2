export class User {
  uname: string;
  password: string;
}
