import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { Router } from '@angular/router';
import { AppService } from '../app.service';


@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
})
export class ListComponent implements OnInit {

  Food: any = [];
  user = new User();
  username: string;

  constructor(private router: Router,
              private appService: AppService)
  {
    this.getFood();
    this.getUser();
  }

  ngOnInit(): void {
  }

  getFood() {
    this.appService.getFood().subscribe((data) => {
      this.Food = data;
    });
  }

  delete(id) {
    this.appService.deleteFood(id).subscribe(() => {
      alert("The deletion of the employee data was successful.");
      this.getFood();
    }, (err) => {
      alert("An error occurred while deleting the employee data : " + err.message);
      this.getFood();
    });
  }
  getUser(){

    if (this.appService.getLoggedInUser().uname == null)
    {
      this.router.navigate(['/login']);
    }

    this.user = this.appService.getLoggedInUser();
    this.username = JSON.stringify(this.user.uname);
  }

  logout(){
    this.user = new User();
    this.appService.setLoggedInUser(this.user);
    this.router.navigate(['/login']);
  }
}
