import { Component } from '@angular/core';
//import { AppService } from '../AppService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'assignment';
 // constructor(public appService : AppService) { }
}
